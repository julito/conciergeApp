import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transportation',
  templateUrl: './transportation.page.html',
  styleUrls: ['./transportation.page.scss'],
})
export class TransportationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
