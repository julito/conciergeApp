import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-boat-renatl',
  templateUrl: './boat-renatl.page.html',
  styleUrls: ['./boat-renatl.page.scss'],
})
export class BoatRenatlPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
