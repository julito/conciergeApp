import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-car-rental',
  templateUrl: './car-rental.page.html',
  styleUrls: ['./car-rental.page.scss'],
})
export class CarRentalPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
