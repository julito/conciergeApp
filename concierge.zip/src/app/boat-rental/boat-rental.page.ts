import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-boat-rental',
  templateUrl: './boat-rental.page.html',
  styleUrls: ['./boat-rental.page.scss'],
})
export class BoatRentalPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
