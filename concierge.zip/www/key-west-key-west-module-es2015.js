(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["key-west-key-west-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/key-west/key-west.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/key-west/key-west.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"danger\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Key West</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-thumbnail item-left=\"\" style=\"background-image: url(https://conciergehotline.net/images/fondo_concierge.png);background-size: 100%;width: 100%;height: 150px;background-repeat: no-repeat;padding-top: 75px;\">\n   \n    <ion-searchbar color=\"light\" debounce=\"500\" (ionChange)=\"Cargar_Productos()\" [(ngModel)]=\"buscar\" placeholder=\"Search...\"></ion-searchbar>\n  </ion-thumbnail>\n  <ion-card *ngFor=\"let producto of productos\">\n    <img src=\"https://conciergehotline.net/images/productos/tour/preview/{{producto.nombre.replaceAll(' ','-') }}.jpg\" />\n    <ion-card-header>\n      <ion-card-title>{{producto.nombre}}</ion-card-title>\n      <ion-badge color=\"danger\">From: $ {{producto.ADULT}}</ion-badge>\n    </ion-card-header>\n    <ion-card-content>\n     \n     <ion-button (click)='detallesProducto(producto)' color=\"danger\" expand=\"full\">Buy Tickets</ion-button>\n    </ion-card-content>\n  </ion-card>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/key-west/key-west-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/key-west/key-west-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: KeyWestPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "KeyWestPageRoutingModule", function() { return KeyWestPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _key_west_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./key-west.page */ "./src/app/key-west/key-west.page.ts");




const routes = [
    {
        path: '',
        component: _key_west_page__WEBPACK_IMPORTED_MODULE_3__["KeyWestPage"]
    }
];
let KeyWestPageRoutingModule = class KeyWestPageRoutingModule {
};
KeyWestPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], KeyWestPageRoutingModule);



/***/ }),

/***/ "./src/app/key-west/key-west.module.ts":
/*!*********************************************!*\
  !*** ./src/app/key-west/key-west.module.ts ***!
  \*********************************************/
/*! exports provided: KeyWestPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "KeyWestPageModule", function() { return KeyWestPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _key_west_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./key-west-routing.module */ "./src/app/key-west/key-west-routing.module.ts");
/* harmony import */ var _key_west_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./key-west.page */ "./src/app/key-west/key-west.page.ts");







let KeyWestPageModule = class KeyWestPageModule {
};
KeyWestPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _key_west_routing_module__WEBPACK_IMPORTED_MODULE_5__["KeyWestPageRoutingModule"]
        ],
        declarations: [_key_west_page__WEBPACK_IMPORTED_MODULE_6__["KeyWestPage"]]
    })
], KeyWestPageModule);



/***/ }),

/***/ "./src/app/key-west/key-west.page.scss":
/*!*********************************************!*\
  !*** ./src/app/key-west/key-west.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-card-header {\n  text-align: center;\n}\n\nion-card-title {\n  font-size: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAva2V5LXdlc3Qva2V5LXdlc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7QUFDSjs7QUFDQTtFQUNJLGVBQUE7QUFFSiIsImZpbGUiOiJzcmMvYXBwL2tleS13ZXN0L2tleS13ZXN0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jYXJkLWhlYWRlcntcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5pb24tY2FyZC10aXRsZXtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxufSJdfQ== */");

/***/ }),

/***/ "./src/app/key-west/key-west.page.ts":
/*!*******************************************!*\
  !*** ./src/app/key-west/key-west.page.ts ***!
  \*******************************************/
/*! exports provided: KeyWestPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "KeyWestPage", function() { return KeyWestPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _servicios_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../servicios.service */ "./src/app/servicios.service.ts");





let KeyWestPage = class KeyWestPage {
    constructor(servicio, route, loading) {
        this.servicio = servicio;
        this.route = route;
        this.loading = loading;
        this.buscar = '';
    }
    ngOnInit() {
        this.Cargar_Productos();
    }
    Cargar_Productos() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let l = yield this.loading.create();
            l.present();
            this.servicio.producto_listado(this.buscar, '6')
                .subscribe((data) => {
                console.log(data);
                this.productos = data;
                l.dismiss();
            }, (error) => {
                console.log(error);
                l.dismiss();
            });
        });
    }
    detallesProducto(item) {
        this.servicio.irA('/producto/' + item.id_producto);
    }
};
KeyWestPage.ctorParameters = () => [
    { type: _servicios_service__WEBPACK_IMPORTED_MODULE_4__["ServiciosService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] }
];
KeyWestPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-key-west',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./key-west.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/key-west/key-west.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./key-west.page.scss */ "./src/app/key-west/key-west.page.scss")).default]
    })
], KeyWestPage);



/***/ })

}]);
//# sourceMappingURL=key-west-key-west-module-es2015.js.map