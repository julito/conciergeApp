(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tours-tours-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/tours/tours.page.html":
    /*!*****************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tours/tours.page.html ***!
      \*****************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppToursToursPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"danger\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Tours and Activities</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-thumbnail item-left=\"\" style=\"background-image: url(https://conciergehotline.net/images/fondo_concierge.png);background-size: 100%;width: 100%;height: 150px;background-repeat: no-repeat;padding-top: 75px;\">\n   \n    <ion-searchbar color=\"light\" debounce=\"500\" (ionChange)=\"Cargar_Productos()\" [(ngModel)]=\"buscar\" placeholder=\"Search...\"></ion-searchbar>\n  </ion-thumbnail>\n  <ion-card *ngFor=\"let producto of productos\">\n    <img src=\"https://conciergehotline.net/images/productos/tour/preview/{{producto.nombre.replaceAll(' ','-') }}.jpg\" />\n    <ion-card-header>\n      <ion-card-title>{{producto.nombre}}</ion-card-title>\n      <ion-badge color=\"danger\">From: $ {{producto.ADULT}}</ion-badge>\n    </ion-card-header>\n    <ion-card-content>\n     \n     <ion-button (click)='detallesProducto(producto)' color=\"danger\" expand=\"full\">Buy Tickets</ion-button>\n    </ion-card-content>\n  </ion-card>\n</ion-content>\n\n\n<ion-footer class=\"ion-no-border\" color=\"danger\">\n  <ion-toolbar>\n    <ion-tabs>\n      <ion-tab-bar slot=\"bottom\">\n        <ion-tab-button tab=\"schedule\">\n          <ion-icon name=\"images-outline\"></ion-icon>\n          <ion-label>Gallery</ion-label>\n         \n        </ion-tab-button>\n    \n        <ion-tab-button tab=\"speakers\">\n          <ion-icon name=\"chatbubbles-outline\"></ion-icon>\n          <ion-label>Contact Us</ion-label>\n        </ion-tab-button>\n    \n        <ion-tab-button tab=\"about\">\n          <ion-icon name=\"information-circle\"></ion-icon>\n          <ion-label>About</ion-label>\n        </ion-tab-button>\n      </ion-tab-bar>\n    </ion-tabs>\n  </ion-toolbar>\n</ion-footer>";
      /***/
    },

    /***/
    "./src/app/tours/tours-routing.module.ts":
    /*!***********************************************!*\
      !*** ./src/app/tours/tours-routing.module.ts ***!
      \***********************************************/

    /*! exports provided: ToursPageRoutingModule */

    /***/
    function srcAppToursToursRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ToursPageRoutingModule", function () {
        return ToursPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _tours_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./tours.page */
      "./src/app/tours/tours.page.ts");

      var routes = [{
        path: '',
        component: _tours_page__WEBPACK_IMPORTED_MODULE_3__["ToursPage"]
      }];

      var ToursPageRoutingModule = function ToursPageRoutingModule() {
        _classCallCheck(this, ToursPageRoutingModule);
      };

      ToursPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], ToursPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/tours/tours.module.ts":
    /*!***************************************!*\
      !*** ./src/app/tours/tours.module.ts ***!
      \***************************************/

    /*! exports provided: ToursPageModule */

    /***/
    function srcAppToursToursModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ToursPageModule", function () {
        return ToursPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _tours_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./tours-routing.module */
      "./src/app/tours/tours-routing.module.ts");
      /* harmony import */


      var _tours_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./tours.page */
      "./src/app/tours/tours.page.ts");

      var ToursPageModule = function ToursPageModule() {
        _classCallCheck(this, ToursPageModule);
      };

      ToursPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _tours_routing_module__WEBPACK_IMPORTED_MODULE_5__["ToursPageRoutingModule"]],
        declarations: [_tours_page__WEBPACK_IMPORTED_MODULE_6__["ToursPage"]]
      })], ToursPageModule);
      /***/
    },

    /***/
    "./src/app/tours/tours.page.scss":
    /*!***************************************!*\
      !*** ./src/app/tours/tours.page.scss ***!
      \***************************************/

    /*! exports provided: default */

    /***/
    function srcAppToursToursPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-card-header {\n  text-align: center;\n}\n\nion-card-title {\n  font-size: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdG91cnMvdG91cnMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7QUFDSjs7QUFDQTtFQUNJLGVBQUE7QUFFSiIsImZpbGUiOiJzcmMvYXBwL3RvdXJzL3RvdXJzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jYXJkLWhlYWRlcntcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5pb24tY2FyZC10aXRsZXtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxufSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/tours/tours.page.ts":
    /*!*************************************!*\
      !*** ./src/app/tours/tours.page.ts ***!
      \*************************************/

    /*! exports provided: ToursPage */

    /***/
    function srcAppToursToursPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ToursPage", function () {
        return ToursPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _servicios_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../servicios.service */
      "./src/app/servicios.service.ts");

      var ToursPage = /*#__PURE__*/function () {
        function ToursPage(servicio, route, loading) {
          _classCallCheck(this, ToursPage);

          this.servicio = servicio;
          this.route = route;
          this.loading = loading;
          this.buscar = '';
        }

        _createClass(ToursPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.Cargar_Productos();
          }
        }, {
          key: "Cargar_Productos",
          value: function Cargar_Productos() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this = this;

              var l;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.loading.create();

                    case 2:
                      l = _context.sent;
                      l.present();
                      this.servicio.producto_listado(this.buscar).subscribe(function (data) {
                        console.log(data);
                        _this.productos = data;
                        l.dismiss();
                      }, function (error) {
                        l.dismiss();
                      });

                    case 5:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "detallesProducto",
          value: function detallesProducto(item) {
            this.servicio.irA('/producto/' + item.id_producto);
          }
        }]);

        return ToursPage;
      }();

      ToursPage.ctorParameters = function () {
        return [{
          type: _servicios_service__WEBPACK_IMPORTED_MODULE_4__["ServiciosService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]
        }];
      };

      ToursPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-tours',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./tours.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/tours/tours.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./tours.page.scss */
        "./src/app/tours/tours.page.scss"))["default"]]
      })], ToursPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=tours-tours-module-es5.js.map