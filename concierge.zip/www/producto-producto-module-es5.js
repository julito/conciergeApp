(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["producto-producto-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/producto/producto.page.html":
    /*!***********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/producto/producto.page.html ***!
      \***********************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppProductoProductoPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"danger\">\n\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" defaultHref=\"home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title >Product</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content  *ngFor=\"let producto of productos\">\n  \n  <ion-slides pager=\"true\" >\n\n    <ion-slide>\n      <div class=\"slide\">\n        <img src=\"https://conciergehotline.net/images/productos/slide/{{producto.nombre.replaceAll(' ','-') }}/A.jpg\"/>\n             \n      </div>\n    </ion-slide>\n\n    <ion-slide>\n      <img src=\"https://conciergehotline.net/images/productos/slide/{{producto.nombre.replaceAll(' ','-') }}/B.jpg\"/>\n   \n    </ion-slide>\n\n    <ion-slide>\n      <img src=\"https://conciergehotline.net/images/productos/slide/{{producto.nombre.replaceAll(' ','-') }}/C.jpg\"/>\n   \n    </ion-slide>\n\n    <ion-slide>\n      <img src=\"https://conciergehotline.net/images/productos/slide/{{producto.nombre.replaceAll(' ','-') }}/D.jpg\"/>\n     \n    </ion-slide>\n\n  </ion-slides>\n\n<h4 style=\"text-align: center;\">{{producto.nombre}}</h4>\n  <ion-list>\n    <ion-item>\n      <ion-label position=\"floating\">Date</ion-label>\n      <ion-datetime displayFormat=\"MM/DD/YYYY\" min=\"2020-12-10\" max=\"2021-12-31\" value=\"\"></ion-datetime>\n    </ion-item>\n    \n    <ion-item>\n      <ion-label>Adult</ion-label>\n      <ion-select position=\"floating\" value=\"0\" okText=\"Okay\" cancelText=\"Dismiss\">\n        <ion-select-option value=\"1\">1</ion-select-option>\n        <ion-select-option value=\"2\">2</ion-select-option>\n        <ion-select-option value=\"3\">3</ion-select-option>\n        <ion-select-option value=\"4\">4</ion-select-option>\n        <ion-select-option value=\"5\">5</ion-select-option>\n        <ion-select-option value=\"6\">6</ion-select-option>\n        <ion-select-option value=\"7\">7</ion-select-option>\n        <ion-select-option value=\"8\">8</ion-select-option>\n        <ion-select-option value=\"9\">9</ion-select-option>\n        <ion-select-option value=\"10\">10</ion-select-option>\n        \n      </ion-select>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>Child</ion-label>\n      <ion-select position=\"floating\" value=\"0\" okText=\"Okay\" cancelText=\"Dismiss\">\n        <ion-select-option value=\"1\">1</ion-select-option>\n        <ion-select-option value=\"2\">2</ion-select-option>\n        <ion-select-option value=\"3\">3</ion-select-option>\n        <ion-select-option value=\"4\">4</ion-select-option>\n        <ion-select-option value=\"5\">5</ion-select-option>\n        <ion-select-option value=\"6\">6</ion-select-option>\n        <ion-select-option value=\"7\">7</ion-select-option>\n        <ion-select-option value=\"8\">8</ion-select-option>\n        <ion-select-option value=\"9\">9</ion-select-option>\n        <ion-select-option value=\"10\">10</ion-select-option>\n        \n      </ion-select>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>Hotel</ion-label>\n      <ion-select position=\"floating\" value=\"0\" okText=\"Okay\" cancelText=\"Dismiss\">\n        <ion-select-option value=\"name\">name</ion-select-option>\n      \n        \n      </ion-select>\n    </ion-item>\n\n\n  </ion-list>\n\n\n  <ion-list>\n    <ion-item-sliding *ngFor=\"let producto of productos\" #ionItemSliding>\n      <ion-item>\n        <ion-thumbnail slot=\"start\">\n          <img src=\"https://conciergehotline.net/images/productos/tour/preview/{{producto.nombre.replaceAll(' ','-') }}.jpg\" />\n        </ion-thumbnail>\n        <ion-label text-wrap>\n          <h2>{{producto.nombre}}</h2>\n          \n          <p>Price:$ {{precio_pagar|number}}</p>\n        </ion-label>\n        <ion-badge slot=\"end\" color=\"danger\">{{producto.codigo}}</ion-badge>\n      </ion-item>\n      <ion-item-options side=\"end\">\n        <ion-item-option color=\"warning\" (click)=\"Editar(producto, ionItemSliding)\">Keep Shopping</ion-item-option>\n        <ion-item-option color=\"danger\" (click)=\"Borrar(producto, ionItemSliding)\">Procced to Pay</ion-item-option>\n      </ion-item-options>\n    </ion-item-sliding>\n  </ion-list>\n\n\n\n  <ion-grid>\n    <ion-row>\n      <ion-col>\n        <div [innerHTML]=producto.INCLUDE></div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n    \n  \n  \n  \n\n  \n\n\n\n\n</ion-content>\n<ion-footer class=\"ion-no-border\" color=\"danger\">\n  <ion-toolbar>\n    <ion-tabs>\n      <ion-tab-bar slot=\"bottom\">\n        <ion-tab-button tab=\"schedule\">\n          <ion-icon name=\"images-outline\"></ion-icon>\n          <ion-label>Gallery</ion-label>\n         \n        </ion-tab-button>\n    \n        <ion-tab-button tab=\"speakers\">\n          <ion-icon name=\"chatbubbles-outline\"></ion-icon>\n          <ion-label>Contact Us</ion-label>\n        </ion-tab-button>\n    \n        <ion-tab-button tab=\"about\">\n          <ion-icon name=\"information-circle\"></ion-icon>\n          <ion-label>About</ion-label>\n        </ion-tab-button>\n      </ion-tab-bar>\n    </ion-tabs>\n  </ion-toolbar>\n</ion-footer>";
      /***/
    },

    /***/
    "./src/app/producto/producto-routing.module.ts":
    /*!*****************************************************!*\
      !*** ./src/app/producto/producto-routing.module.ts ***!
      \*****************************************************/

    /*! exports provided: ProductoPageRoutingModule */

    /***/
    function srcAppProductoProductoRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ProductoPageRoutingModule", function () {
        return ProductoPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _producto_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./producto.page */
      "./src/app/producto/producto.page.ts");

      var routes = [{
        path: '',
        component: _producto_page__WEBPACK_IMPORTED_MODULE_3__["ProductoPage"]
      }];

      var ProductoPageRoutingModule = function ProductoPageRoutingModule() {
        _classCallCheck(this, ProductoPageRoutingModule);
      };

      ProductoPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], ProductoPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/producto/producto.module.ts":
    /*!*********************************************!*\
      !*** ./src/app/producto/producto.module.ts ***!
      \*********************************************/

    /*! exports provided: ProductoPageModule */

    /***/
    function srcAppProductoProductoModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ProductoPageModule", function () {
        return ProductoPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _producto_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./producto-routing.module */
      "./src/app/producto/producto-routing.module.ts");
      /* harmony import */


      var _producto_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./producto.page */
      "./src/app/producto/producto.page.ts");

      var ProductoPageModule = function ProductoPageModule() {
        _classCallCheck(this, ProductoPageModule);
      };

      ProductoPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _producto_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProductoPageRoutingModule"]],
        declarations: [_producto_page__WEBPACK_IMPORTED_MODULE_6__["ProductoPage"]]
      })], ProductoPageModule);
      /***/
    },

    /***/
    "./src/app/producto/producto.page.scss":
    /*!*********************************************!*\
      !*** ./src/app/producto/producto.page.scss ***!
      \*********************************************/

    /*! exports provided: default */

    /***/
    function srcAppProductoProductoPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-card-content {\n  text-align: center;\n}\n\nion-icon {\n  font-size: 50px;\n}\n\nion-card-title {\n  font-size: 16px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvZHVjdG8vcHJvZHVjdG8ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7QUFDRjs7QUFFQTtFQUNFLGVBQUE7QUFDRjs7QUFFQTtFQUNFLGVBQUE7QUFDRiIsImZpbGUiOiJzcmMvYXBwL3Byb2R1Y3RvL3Byb2R1Y3RvLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jYXJkLWNvbnRlbnQge1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuaW9uLWljb24ge1xyXG4gIGZvbnQtc2l6ZTogNTBweDtcclxufVxyXG5cclxuaW9uLWNhcmQtdGl0bGV7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG59Il19 */";
      /***/
    },

    /***/
    "./src/app/producto/producto.page.ts":
    /*!*******************************************!*\
      !*** ./src/app/producto/producto.page.ts ***!
      \*******************************************/

    /*! exports provided: ProductoPage */

    /***/
    function srcAppProductoProductoPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ProductoPage", function () {
        return ProductoPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _servicios_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../servicios.service */
      "./src/app/servicios.service.ts");

      var ProductoPage = /*#__PURE__*/function () {
        function ProductoPage(servicio, route, loading) {
          _classCallCheck(this, ProductoPage);

          this.servicio = servicio;
          this.route = route;
          this.loading = loading;
          this.buscar = '';
          this.precio_pagar = 0;
          this.slideOpts = {
            initialSlide: 0,
            speed: 400
          };
          this.id = 0;
          this.id = this.route.snapshot.params.productoId ? this.route.snapshot.params.productoId : 0;
          console.log(this.id);
        }

        _createClass(ProductoPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.Cargar_Producto();
          }
        }, {
          key: "Cargar_Producto",
          value: function Cargar_Producto() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this = this;

              var l;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.loading.create();

                    case 2:
                      l = _context.sent;
                      l.present();
                      this.servicio.get_producto(this.id).subscribe(function (data) {
                        _this.productos = data;
                        console.log(_this.productos[0].ADULT);
                        _this.precio_pagar = _this.productos[0].ADULT;
                        l.dismiss();
                      }, function (error) {
                        console.log(error);
                        l.dismiss();
                      });

                    case 5:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }]);

        return ProductoPage;
      }();

      ProductoPage.ctorParameters = function () {
        return [{
          type: _servicios_service__WEBPACK_IMPORTED_MODULE_4__["ServiciosService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]
        }];
      };

      ProductoPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-producto',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./producto.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/producto/producto.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./producto.page.scss */
        "./src/app/producto/producto.page.scss"))["default"]]
      })], ProductoPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=producto-producto-module-es5.js.map